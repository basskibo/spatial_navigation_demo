import React from "react";
import { ShelfConfig } from "../store/shelvesSlice";
import ShelfTypeA from "./shelves/ShelfTypeA";
import ShelfTypeB from "./shelves/ShelfTypeB";
import ShelfTypeC from "./shelves/ShelfTypeC";
import {
   FocusContext,
   useFocusable,
} from "@noriginmedia/norigin-spatial-navigation";

interface Props {
   config: ShelfConfig;
   parentFocusKey: string;
}
const ShelfRenderer: React.FC<Props> = ({ config, parentFocusKey }) => {
   const { ref, focusKey } = useFocusable({
      focusKey: `${parentFocusKey}-${config.id}`,
      isFocusBoundary: false, // Changed from true to false
      saveLastFocusedChild: true,
   });
   console.log(`##### ShelfRenderer: ${parentFocusKey}-shelf-${config.id}`);

   return (
      <FocusContext.Provider value={focusKey}>
         <div ref={ref}>
            {config.type === "TYPE_A" && (
               <ShelfTypeA config={config} parentKey={focusKey} />
            )}
            {config.type === "TYPE_B" && (
               <ShelfTypeB config={config} parentKey={focusKey} />
            )}
         </div>
      </FocusContext.Provider>
   );
};

export default React.memo(ShelfRenderer);
