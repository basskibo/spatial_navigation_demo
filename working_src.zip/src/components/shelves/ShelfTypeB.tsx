import React, { useEffect, useState, useContext} from "react";
import { ShelfConfig } from "../../store/shelvesSlice";
import {
   FocusContext,
   useFocusable,

} from "@noriginmedia/norigin-spatial-navigation";

interface Props {
   config: ShelfConfig;
    parentKey: string;
}

interface ShelfProps {
   item: string;
   config: {
      title: string;
   };
   index: number;
   parentKey: string;

}

const ShelfTypeB: React.FC<Props> = ({ config, parentKey }) => { // Changed prop name
    const [items, setItems] = useState<string[]>([]);
   const [error, setError] = useState<string | null>(null);
   console.log(`##### ShelfTypeA ${parentKey}-${config.title}`)

    const { ref, focusKey } = useFocusable({
       focusKey: `${parentKey}-${config.title}`, // Use parentKey in focusKey
       trackChildren: true,
       isFocusBoundary: false, // Changed from true to false
       focusable: true,
    });


   const focusContext = useContext(FocusContext)
   console.log("Parent focus key:", focusContext);

   useEffect(() => {
    console.log('Shelf focusKey:', focusKey);
  }, [focusKey]);

   useEffect(() => {
      setTimeout(() => {
         if (config.fail) {
            setError("Failed to load TYPE_A data");
         } else {
            setItems([
                'TRUEID +',
                'NOW',
                'FITURE',
                'Plern',
                'iQIYI',
                'Viu',
            ]);
         }
      }, 500);
   }, [config]);

   if (error) return <div>{error}</div>;

   return (
      <FocusContext.Provider value={focusKey}>
         <div ref={ref} style={{ marginBottom: "32px" }}>
            <h3 style={{ color: "#fff", marginBottom: "12px" }}>
               {config.title}
            </h3>
            <div
               style={{
                  display: "flex",
                  gap: "12px",
                  overflowX: "auto",
                  padding: "10px 0",
               }}
            >
               {items.map((item, idx) => (
                  <ShelfItem
                     key={idx}
                     item={item}
                     config={config}
                     parentKey={parentKey}
                     index={idx}
                  />
               ))}
            </div>
         </div>
      </FocusContext.Provider>
   );
};

// ShelfTypeA.tsx - ShelfItem component
const ShelfItem: React.FC<ShelfProps> = ({ item, config, index, parentKey }) => {
    console.log(`##### ShelfItem ${parentKey}-item-${index}`)
    const { ref, focused } = useFocusable({
        focusKey: `${parentKey}-item-${index}`,
        onFocus: () => {
          console.log(`Focused: ${config.title}-item-${index}`);
        },
        extraProps: {
          item,
          index
        }
    });



  useEffect(() => {
    console.log(`Item ${index} focused:`, focused);

    if (focused && ref.current) {
      ref.current.scrollIntoView({ 
        behavior: "smooth", 
        block: "nearest",
        inline: "center" 
      });
    }
  }, [focused]);
  
   return (
      <div
         ref={ref}
         tabIndex={-1}
         className='focusable'
         style={{
            minWidth: "240px",
            height: "100px",
            backgroundColor: focused ? "#0f62fe" : "#333",
            color: "#fff",
            borderRadius: "12px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontWeight: "bold",
            flexShrink: 0,
            boxShadow: "0 2px 4px rgba(0,0,0,0.3)",
         }}
      >
         {item}
      </div>
   );
};

export default ShelfTypeB;
