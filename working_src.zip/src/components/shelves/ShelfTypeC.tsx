import React, { useEffect, useState } from 'react';
import { ShelfConfig } from '../../store/shelvesSlice';
import { useFocusable } from '@noriginmedia/norigin-spatial-navigation';

interface Props {
  config: ShelfConfig;
}

const ShelfTypeC: React.FC<Props> = ({ config }) => {
  const [items, setItems] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  const { ref } = useFocusable();

  useEffect(() => {
    setTimeout(() => {
      if (config.fail) {
        setError('Failed to load TYPE_B data');
      } else {
        setItems([
          'Hotel del Luna',
          'Jade Dynasty',
          'The world of married',
          'Plern',
          'iQIYI',
          'Viu',
        ]);
      }
    }, 500);
  }, [config]);

  if (error) return <div>{error}</div>;

  return (
    <div ref={ref} style={{ marginBottom: '32px' }}>
      <h3 style={{ color: '#fff', marginBottom: '12px' }}>{config.title}</h3>
      <div
        style={{
          display: 'flex',
          gap: '12px',
          overflowX: 'auto',
          padding: '10px 0',
        }}
      >
        {items.map((item, idx) => (
          <div
            key={idx}
            style={{
              minWidth: '240px',
              height: '320px',
              backgroundColor: '#333',
              color: '#fff',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 'bold',
              flexShrink: 0,
              boxShadow: '0 2px 4px rgba(0,0,0,0.3)',
            }}
          >
            {item}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ShelfTypeC;
